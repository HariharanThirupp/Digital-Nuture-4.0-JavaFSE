public class Book implements Product {
    public void showDetails() {
        System.out.println("This is a Book.");
    }
}
