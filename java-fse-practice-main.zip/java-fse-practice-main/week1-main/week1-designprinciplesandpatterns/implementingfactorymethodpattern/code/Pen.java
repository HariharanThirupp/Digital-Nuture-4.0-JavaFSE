public class Pen implements Product {
    public void showDetails() {
        System.out.println("This is a Pen.");
    }
}
