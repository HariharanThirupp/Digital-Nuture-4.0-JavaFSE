public interface Product {
    void showDetails();
}
