package com.example.repository;

public class BookRepository {
    public void getBooks() {
        System.out.println("Fetching list of books from the repository...");
    }
}
