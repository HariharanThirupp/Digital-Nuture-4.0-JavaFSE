package com.example.repository;

public class BookRepository {
    public void findAllBooks() {
        System.out.println("BookRepository: fetching all books from DB...");
    }
}
