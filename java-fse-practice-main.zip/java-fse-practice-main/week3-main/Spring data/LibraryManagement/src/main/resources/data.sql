
INSERT INTO country (code, name) VALUES ('IN', 'India'), ('US', 'United States');
