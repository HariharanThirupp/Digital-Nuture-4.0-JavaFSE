package com.example;

public @interface EnableEurekaServer {
    
}
